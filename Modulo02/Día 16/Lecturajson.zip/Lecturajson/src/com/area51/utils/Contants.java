package com.area51.utils;

public class Contants {
	public static String TAG_APP="LecturaApp";
	public static String API = "http://segundoacosta.com/";
	public static String API_VERSION = "area51api/";
	public static String API_SECTION="listado.php?";

	public static String API_RESPONSE_VAL = "OK";
	public static String API_RESPONSE = "response";
	public static String API_DATA = "data";
	public static String API_TOTAL = "total";
}
