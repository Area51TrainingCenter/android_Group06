package com.area51.utils;

public class ConstantsApp {

	public static final String TAG_APP = "Proyecto";

}
