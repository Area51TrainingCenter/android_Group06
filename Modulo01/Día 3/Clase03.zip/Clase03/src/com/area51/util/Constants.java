package com.area51.util;

import java.util.ArrayList;

import com.area51.model.Item;

public class Constants {
	public static ArrayList<Item> lista;
}
